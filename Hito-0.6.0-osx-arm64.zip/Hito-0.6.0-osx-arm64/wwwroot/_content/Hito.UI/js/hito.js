// Utilidades de navegador para Hito (web y escritorio). Sin dependencias.

// ---------- Diagnóstico ----------
// En la versión portable, los errores de la ventana se anotan en hito.log (no salen del equipo).
(() => {
  if (location.hostname !== '127.0.0.1') return;
  const send = (kind, msg) => {
    try { navigator.sendBeacon('/__hito/cliente', `${kind}: ${msg}`.slice(0, 2000)); } catch { }
  };
  window.__hitoReport = send;
  window.addEventListener('error', e => send('error', `${e.message} @ ${e.filename}:${e.lineno}` + (e.target && e.target !== window ? ` (no cargó ${e.target.src || e.target.href})` : '')), true);
  window.addEventListener('unhandledrejection', e => send('promesa', String(e.reason?.stack || e.reason)));
  for (const level of ['error', 'warn']) {
    const original = console[level].bind(console);
    console[level] = (...args) => { send('console.' + level, args.map(a => a?.stack || (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ')); original(...args); };
  }
  send('inicio', `${navigator.userAgent} · ${innerWidth}×${innerHeight}`);
})();

// ---------- Pantalla de carga ----------
// Se dibuja en cuanto carga este archivo (antes que Blazor) y se quita cuando la app avisa
// que está lista (hito.ready). La primera apertura dura al menos 2.8 s: la barra se llena color por
// color y la firma se alcanza a apreciar. Las recargas no esperan de más.
(() => {
  if (document.getElementById('hito-splash')) return;
  // Logotipo: mismos trazos que Wordmark.razor (marca/fuente/logo.py).
  const wordmark = '<svg class="wm-word" viewBox="0 -76.76 202.70 76.76" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20.9 -31.59V0H6.25V-72.75H20.61V-40.97H19.43Q21.58 -47.8 25.95 -51.54Q30.32 -55.27 37.26 -55.27Q42.92 -55.27 47.14 -52.81Q51.37 -50.34 53.69 -45.73Q56.01 -41.11 56.01 -34.72V0H41.36V-32.18Q41.36 -37.26 38.75 -40.14Q36.13 -43.02 31.49 -43.02Q28.42 -43.02 26 -41.67Q23.58 -40.33 22.24 -37.79Q20.9 -35.25 20.9 -31.59Z M64.01 0V-54.59H78.65V0Z M113.71 -54.59V-43.41H81.33V-54.59ZM88.85 -67.58H103.5V-15.97Q103.5 -13.38 104.65 -12.13Q105.79 -10.89 108.48 -10.89Q109.31 -10.89 110.82 -11.11Q112.34 -11.33 113.12 -11.52L115.22 -0.54Q112.78 0.2 110.36 0.49Q107.94 0.78 105.75 0.78Q97.54 0.78 93.2 -3.22Q88.85 -7.23 88.85 -14.7Z M143.14 1.07Q134.94 1.07 128.93 -2.47Q122.93 -6.01 119.68 -12.33Q116.43 -18.65 116.43 -27.05Q116.43 -35.55 119.68 -41.87Q122.93 -48.19 128.93 -51.73Q134.94 -55.27 143.14 -55.27Q151.39 -55.27 157.37 -51.73Q163.36 -48.19 166.6 -41.87Q169.85 -35.55 169.85 -27.05Q169.85 -18.65 166.6 -12.33Q163.36 -6.01 157.37 -2.47Q151.39 1.07 143.14 1.07ZM143.14 -10.45Q147.05 -10.45 149.68 -12.62Q152.32 -14.79 153.64 -18.58Q154.96 -22.36 154.96 -27.1Q154.96 -31.93 153.64 -35.69Q152.32 -39.45 149.68 -41.6Q147.05 -43.75 143.14 -43.75Q139.23 -43.75 136.62 -41.6Q134.01 -39.45 132.69 -35.69Q131.37 -31.93 131.37 -27.1Q131.37 -22.36 132.69 -18.58Q134.01 -14.79 136.62 -12.62Q139.23 -10.45 143.14 -10.45Z M186 0.93Q182.44 0.93 180 -1.49Q177.56 -3.91 177.56 -7.47Q177.56 -11.04 180 -13.43Q182.44 -15.82 186 -15.82Q189.57 -15.82 192.01 -13.43Q194.45 -11.04 194.45 -7.47Q194.45 -3.91 192.01 -1.49Q189.57 0.93 186 0.93Z"/><rect x="63.27" y="-76.76" width="16.11" height="16.11" rx="2.93"/></svg>';
  const colors = ['#7FB3F5', '#C9A7F5', '#F28B6E', '#8FD19E', '#E3E07A', '#F4B740', '#F5A3C7'];
  const github = 'M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z';
  // La intro sale antes de que cargue la app: usa el último idioma elegido, o el del sistema.
  let lang = 'es';
  try { lang = localStorage.getItem('hito-lang') || ((navigator.language || 'es').toLowerCase().startsWith('es') ? 'es' : 'en'); } catch { }
  const tx = lang === 'en'
    ? { loading: 'Loading your schedule…', label: 'Loading Hito', stuck: "Hito didn't finish opening. Close the window and open it again; if it keeps happening, the hito.log file (in the data folder) explains why." }
    : { loading: 'Cargando tu agenda…', label: 'Cargando Hito', stuck: 'Hito no terminó de abrir. Cierra la ventana y vuelve a abrirlo; si se repite, el archivo hito.log (en la carpeta datos) dice por qué.' };
  document.documentElement.lang = lang;
  const el = document.createElement('div');
  el.id = 'hito-splash';
  el.setAttribute('role', 'status');
  el.setAttribute('aria-label', tx.label);
  el.innerHTML = `
    <div class="sp-center">
      <div class="sp-logo wordmark" aria-hidden="true">
        <div class="sp-brand">${wordmark}</div>
        <div class="sp-bar">${colors.map((c, i) => `<span style="background:${c};--i:${i}"></span>`).join('')}</div>
      </div>
      <div class="sp-text">${tx.loading}</div>
    </div>
    <div class="sp-credit">
      <span class="sp-by">Designed by Miguel Huerta</span>
      <span class="sp-gh"><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="${github}"/></svg>@miguelhuerta-dev</span>
    </div>`;
  document.body.prepend(el);

  let firstOfSession = true;
  try { firstOfSession = !sessionStorage.getItem('hito-splash'); sessionStorage.setItem('hito-splash', '1'); } catch { }
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const minUntil = performance.now() + (firstOfSession ? (reduced ? 1500 : 2800) : 0);
  if (!firstOfSession) el.classList.add('is-quick');
  let done = false;

  window.__hitoSplashHide = () => {
    if (done) return;
    done = true;
    setTimeout(() => {
      el.classList.add('is-leaving');
      const remove = () => el.remove();
      el.addEventListener('transitionend', remove, { once: true });
      setTimeout(remove, 600); // por si no hay transición (movimiento reducido)
    }, Math.max(0, minUntil - performance.now()));
  };
  // Si en 15 s no arrancó, decirlo (en vez de quitar la intro y dejar una pantalla vacía).
  setTimeout(() => {
    if (done) return;
    el.classList.add('is-stuck');
    window.__hitoReport?.('atascado', `15 s sin arrancar · readyState=${document.readyState} · Blazor=${typeof window.Blazor} · ruta=${location.href}`);
    el.querySelector('.sp-text').textContent = tx.stuck;
  }, 15000);
})();

// ---------- Menú lateral deslizable (celular) ----------
// La barra lateral de escritorio se vuelve un cajón en pantallas angostas. Se abre con ☰ o
// deslizando desde el borde izquierdo, y se cierra deslizando a la izquierda, tocando afuera,
// con Esc, eligiendo una sección o con el botón Atrás de Android. El cajón sigue al dedo y, al
// soltar, decide por la velocidad del gesto (un "flick" rápido basta) o por cuánto se abrió.
const drawer = (() => {
  const mq = matchMedia('(max-width: 700px)');
  const EDGE = 28;            // px desde el borde izquierdo donde empieza el gesto de abrir
  const LOCK = 8;             // px de movimiento antes de decidir si el gesto es horizontal
  const FLICK = 0.35;         // px/ms: más rápido que esto decide por la dirección
  let open = false, labels = ['Abrir menú', 'Cerrar menú'], ready = false;
  let g = null;               // gesto en curso

  const panel = () => document.getElementById('hito-drawer');
  const scrim = () => document.querySelector('.drawer-scrim');
  const toggles = () => document.querySelectorAll('[data-drawer-toggle]');
  const behind = () => document.querySelectorAll('.topbar, .content');

  function sync() {
    const mobile = mq.matches;
    const p = panel();
    document.documentElement.classList.toggle('drawer-open', mobile && open);
    if (p) p.inert = mobile && !open;                       // cerrado: fuera del orden de tabulación
    behind().forEach(el => { el.inert = mobile && open; });  // abierto: lo de atrás no se alcanza
    toggles().forEach(t => {
      t.setAttribute('aria-expanded', String(mobile && open));
      t.setAttribute('aria-label', labels[open ? 1 : 0]);
    });
  }

  function set(value, { focus = true } = {}) {
    if (open === value) return sync();
    open = value;
    sync();
    if (!focus || !mq.matches) return;
    if (open) (panel()?.querySelector('.nav a.active') || panel()?.querySelector('a, button'))?.focus({ preventScroll: true });
    else toggles()[0]?.focus({ preventScroll: true });
  }

  // --- Gesto ---
  function onStart(e) {
    if (!mq.matches || e.touches.length !== 1 || document.querySelector('.modal-backdrop, .tour-backdrop')) return;
    const t = e.touches[0], p = panel();
    if (!p) return;
    let mode = null;
    if (!open && t.clientX <= EDGE) mode = 'open';
    else if (open && (p.contains(e.target) || e.target === scrim())) mode = 'close';
    if (!mode) return;
    g = { mode, x0: t.clientX, y0: t.clientY, samples: [[t.clientX, performance.now()]], locked: false, w: p.getBoundingClientRect().width, pos: 0 };
  }

  function onMove(e) {
    if (!g) return;
    const t = e.touches[0];
    const dx = t.clientX - g.x0, dy = t.clientY - g.y0;
    if (!g.locked) {
      if (Math.abs(dy) > LOCK && Math.abs(dy) > Math.abs(dx)) { g = null; return; }  // es un scroll vertical
      if (Math.abs(dx) < LOCK) return;
      g.locked = true;
      document.documentElement.classList.add('drawer-dragging');
      if (g.mode === 'open') { panel().inert = false; }
    }
    e.preventDefault();
    // Muestras de los últimos 100 ms: la velocidad del gesto, no la del último pixel.
    const now = performance.now();
    g.samples.push([t.clientX, now]);
    while (g.samples.length > 2 && now - g.samples[0][1] > 100) g.samples.shift();
    // posición: 0 = abierto, -w = cerrado
    g.pos = g.mode === 'open' ? Math.min(0, Math.max(-g.w, dx - g.w)) : Math.min(0, Math.max(-g.w, dx));
    panel().style.transform = `translateX(${g.pos}px)`;
    const s = scrim(); if (s) { s.style.opacity = String(1 + g.pos / g.w); s.style.display = 'block'; }
  }

  function onEnd() {
    if (!g) return;
    const was = g; g = null;
    if (!was.locked) return;
    const progress = 1 + was.pos / was.w;
    const [x1, t1] = was.samples[0], [x2, t2] = was.samples[was.samples.length - 1];
    const idle = performance.now() - t2 > 120;              // el dedo se detuvo antes de soltar
    const v = idle ? 0 : (x2 - x1) / Math.max(1, t2 - t1);
    const result = v > FLICK ? true : v < -FLICK ? false : progress > 0.5;
    const p = panel(), s = scrim();
    document.documentElement.classList.remove('drawer-dragging');
    // Al quitar el estilo en línea, la transición CSS continúa desde donde quedó el dedo.
    p.style.transform = ''; if (s) { s.style.opacity = ''; s.style.display = ''; }
    open = !result; // fuerza a set() a aplicar el cambio
    set(result);
  }

  function onClick(e) {
    if (e.target.closest('[data-drawer-toggle]')) { set(!open); return; }
    if (e.target.closest('[data-drawer-close]')) { set(false); return; }
    if (open && mq.matches && e.target.closest('#hito-drawer a[href]')) set(false, { focus: false });
  }

  function onKey(e) { if (e.key === 'Escape' && open && mq.matches) { e.stopPropagation(); set(false); } }

  return {
    init(openLabel, closeLabel) {
      labels = [openLabel || labels[0], closeLabel || labels[1]];
      if (!ready) {
        ready = true;
        document.addEventListener('touchstart', onStart, { passive: true });
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('touchend', onEnd);
        document.addEventListener('touchcancel', onEnd);
        document.addEventListener('click', onClick);
        document.addEventListener('keydown', onKey, true);
        mq.addEventListener('change', () => { open = false; sync(); });
      }
      sync();
    },
    get isOpen() { return open && mq.matches; },
    open: () => set(true),
    close: () => set(false),
  };
})();

window.hito = {
  // Avisos con notificaciones del navegador (versión web/portable: mientras la ventana esté abierta).
  reminders: {
    timers: [],
    permission() { return 'Notification' in window ? Notification.permission : 'unsupported'; },
    async request() {
      if (!('Notification' in window)) return 'unsupported';
      try { return await Notification.requestPermission(); } catch { return Notification.permission; }
    },
    schedule(list) {
      this.timers.forEach(clearTimeout);
      this.timers = [];
      const now = Date.now();
      for (const r of list || []) {
        const wait = r.at - now;
        if (wait < 0 || wait > 2 ** 31 - 1) continue;
        this.timers.push(setTimeout(() => {
          if (!('Notification' in window) || Notification.permission !== 'granted') return;
          try { new Notification(r.title, { body: r.body, tag: r.key, icon: '/favicon.svg', requireInteraction: true }); } catch { }
        }, wait));
      }
    },
  },
  drawer,
  /** Idioma elegido: lo recuerda para la intro de la próxima vez y lo marca en el documento. */
  setLang(lang) {
    document.documentElement.lang = lang;
    try { localStorage.setItem('hito-lang', lang); } catch { }
  },

  /**
   * Botón Atrás del sistema (Android): cierra lo que esté encima o regresa de sección.
   * Devuelve false cuando ya no hay a dónde regresar.
   */
  back() {
    if (drawer.isOpen) { drawer.close(); return true; }
    const overlay = document.querySelector('.tour-backdrop, .modal-backdrop');
    if (overlay) {
      overlay.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      return true;
    }
    if (location.pathname !== '/') { history.back(); return true; }
    return false;
  },

  /** La app ya mostró sus datos: quita la pantalla de carga. */
  ready() { window.__hitoSplashHide?.(); },

  /** Descarga un archivo de texto generado en .NET (respaldo .json, calendario .ics). */
  download(fileName, mimeType, text) {
    const url = URL.createObjectURL(new Blob([text], { type: mimeType }));
    const a = Object.assign(document.createElement('a'), { href: url, download: fileName });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },

  /** Ctrl/⌘ + K abre la búsqueda; "/" también, si no estás escribiendo. */
  registerShortcuts(dotnet) {
    if (window.__hitoShortcuts) window.removeEventListener('keydown', window.__hitoShortcuts);
    window.__hitoShortcuts = (e) => {
      const typing = e.target.closest?.('input, textarea, select, [contenteditable="true"]');
      if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        dotnet.invokeMethodAsync('OpenSearch');
      } else if (e.key === '/' && !typing && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        dotnet.invokeMethodAsync('OpenSearch');
      }
    };
    window.addEventListener('keydown', window.__hitoShortcuts);
  },

  /** Mantiene visible la opción activa de una lista al moverse con las flechas. */
  scrollIntoView(id) {
    document.getElementById(id)?.scrollIntoView({ block: 'nearest' });
  },

  /** Devuelve el foco al elemento que abrió un diálogo. */
  rememberFocus() { window.__hitoLastFocus = document.activeElement; },
  restoreFocus() { window.__hitoLastFocus?.focus?.({ preventScroll: true }); }
};
