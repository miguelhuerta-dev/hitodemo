// Utilidades de navegador para Hito (web y escritorio). Sin dependencias.

// ---------- Diagnóstico ----------
// En la versión portable, los errores de la ventana se anotan en hito.log (no salen del equipo).
(() => {
  if (location.hostname !== '127.0.0.1') return;
  const send = (kind, msg) => {
    try { navigator.sendBeacon('/__hito/cliente', `${kind}: ${msg}`.slice(0, 2000)); } catch { }
  };
  window.__hitoReport = send;
  window.addEventListener('error', e => send('error', `${e.message} @ ${e.filename}:${e.lineno}` + (e.target && e.target !== window ? ` (no cargó ${e.target.src || e.target.href})` : '')), true);
  window.addEventListener('unhandledrejection', e => send('promesa', String(e.reason?.stack || e.reason)));
  for (const level of ['error', 'warn']) {
    const original = console[level].bind(console);
    console[level] = (...args) => { send('console.' + level, args.map(a => a?.stack || (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ')); original(...args); };
  }
  send('inicio', `${navigator.userAgent} · ${innerWidth}×${innerHeight}`);
})();

// ---------- Pantalla de carga ----------
// Se dibuja en cuanto carga este archivo (antes que Blazor) y se quita cuando la app avisa
// que está lista (hito.ready). La primera apertura de la sesión dura al menos 1.2 s para que
// la firma se alcance a ver; las recargas no esperan de más.
(() => {
  if (document.getElementById('hito-splash')) return;
  const colors = ['#7FB3F5', '#C9A7F5', '#F28B6E', '#8FD19E', '#E3E07A', '#F4B740', '#F5A3C7'];
  const github = 'M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z';
  const el = document.createElement('div');
  el.id = 'hito-splash';
  el.setAttribute('role', 'status');
  el.setAttribute('aria-label', 'Cargando Hito');
  el.innerHTML = `
    <div class="sp-center">
      <div class="sp-brand" aria-hidden="true">hito.</div>
      <div class="sp-bar" aria-hidden="true">${colors.map((c, i) => `<span style="background:${c};--i:${i}"></span>`).join('')}</div>
      <div class="sp-text">Cargando tu agenda…</div>
    </div>
    <div class="sp-credit">
      <span class="sp-by">Designed by Miguel Huerta</span>
      <span class="sp-gh"><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="${github}"/></svg>@miguelhuerta-dev</span>
    </div>`;
  document.body.prepend(el);

  let firstOfSession = true;
  try { firstOfSession = !sessionStorage.getItem('hito-splash'); sessionStorage.setItem('hito-splash', '1'); } catch { }
  const minUntil = performance.now() + (firstOfSession ? 1200 : 0);
  let done = false;

  window.__hitoSplashHide = () => {
    if (done) return;
    done = true;
    setTimeout(() => {
      el.classList.add('is-leaving');
      const remove = () => el.remove();
      el.addEventListener('transitionend', remove, { once: true });
      setTimeout(remove, 600); // por si no hay transición (movimiento reducido)
    }, Math.max(0, minUntil - performance.now()));
  };
  // Si en 15 s no arrancó, decirlo (en vez de quitar la intro y dejar una pantalla vacía).
  setTimeout(() => {
    if (done) return;
    el.classList.add('is-stuck');
    window.__hitoReport?.('atascado', `15 s sin arrancar · readyState=${document.readyState} · Blazor=${typeof window.Blazor} · ruta=${location.href}`);
    el.querySelector('.sp-text').textContent =
      'Hito no terminó de abrir. Cierra la ventana y vuelve a abrirlo; si se repite, el archivo hito.log (en la carpeta datos) dice por qué.';
  }, 15000);
})();

window.hito = {
  /** La app ya mostró sus datos: quita la pantalla de carga. */
  ready() { window.__hitoSplashHide?.(); },

  /** Descarga un archivo de texto generado en .NET (respaldo .json, calendario .ics). */
  download(fileName, mimeType, text) {
    const url = URL.createObjectURL(new Blob([text], { type: mimeType }));
    const a = Object.assign(document.createElement('a'), { href: url, download: fileName });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },

  /** Ctrl/⌘ + K abre la búsqueda; "/" también, si no estás escribiendo. */
  registerShortcuts(dotnet) {
    if (window.__hitoShortcuts) window.removeEventListener('keydown', window.__hitoShortcuts);
    window.__hitoShortcuts = (e) => {
      const typing = e.target.closest?.('input, textarea, select, [contenteditable="true"]');
      if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        dotnet.invokeMethodAsync('OpenSearch');
      } else if (e.key === '/' && !typing && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        dotnet.invokeMethodAsync('OpenSearch');
      }
    };
    window.addEventListener('keydown', window.__hitoShortcuts);
  },

  /** Mantiene visible la opción activa de una lista al moverse con las flechas. */
  scrollIntoView(id) {
    document.getElementById(id)?.scrollIntoView({ block: 'nearest' });
  },

  /** Devuelve el foco al elemento que abrió un diálogo. */
  rememberFocus() { window.__hitoLastFocus = document.activeElement; },
  restoreFocus() { window.__hitoLastFocus?.focus?.({ preventScroll: true }); }
};
